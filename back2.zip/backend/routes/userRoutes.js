const express = require('express');
const { registerUser, loginUser } = require('../controllers/userController');
const { verifyToken } = require('../middlewares/authMiddleware');

const router = express.Router();

// Ruta para registrar usuarios
router.post('/register', registerUser);

// Ruta para autenticar usuarios
router.post('/login', loginUser);

// Ruta protegida de ejemplo
router.get('/profile', verifyToken, (req, res) => {
  res.json({ message: 'Acceso permitido al perfil del usuario.' });
});

module.exports = router;
